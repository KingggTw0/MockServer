using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace SystemTrayApp.Components
{
    public partial class ToastWindow : Window
    {
        private readonly DispatcherTimer _timer;

        public ToastWindow(string title, string message, int durationMs = 3000)
        {
            InitializeComponent();

            TitleText.Text = title;
            MessageText.Text = message;

            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(durationMs)
            };
            _timer.Tick += Timer_Tick;

            Loaded += (_, __) =>
           {
               var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(250));
               BeginAnimation(OpacityProperty, fadeIn);

               var slideUp = new DoubleAnimation
               {
                   From = 20,
                   To = 0,
                   Duration = TimeSpan.FromMilliseconds(350),
                //    EasingFunction = new ElasticEase
                //    {
                //        Oscillations = 2,
                //        Springiness = 5,
                //        EasingMode = EasingMode.EaseOut
                //    }

                   EasingFunction = new BackEase
                   {
                       Amplitude = 0.3,
                       EasingMode = EasingMode.EaseOut
                   }
               };
               ((TranslateTransform)RootBorder.RenderTransform).BeginAnimation(TranslateTransform.YProperty, slideUp);

               _timer.Start();
           };
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            _timer.Stop();

            var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(250));
            fadeOut.Completed += (_, __) => Close();
            BeginAnimation(OpacityProperty, fadeOut);
        }

        public static void Show(string title, string message, int durationMs = 3000)
        {
            var window = new ToastWindow(title, message, durationMs);

            var workingArea = SystemParameters.WorkArea;
            window.Left = workingArea.Right - window.Width - 20;
            window.Top = workingArea.Bottom - window.Height - 40;

            window.Show();
        }
    }
}