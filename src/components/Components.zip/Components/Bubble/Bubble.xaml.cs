using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SystemTrayApp.Components
{
    public partial class BubbleEffect : Window
    {
        private Random random = new Random();
        private DispatcherTimer timer;

        public BubbleEffect()
        {
            InitializeComponent();

            // Thiết lập Timer để tạo bọt khí mới mỗi 0.5 giây
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            TaoBotKhi();
        }

        private void TaoBotKhi()
        {
            // 1. Tạo hình dáng bọt khí
            int size= random.Next(30, 60);
            Ellipse bubble = new Ellipse
            {
                Width = size,
                Height = size,
                Fill = new SolidColorBrush(Colors.White) { Opacity = 0.6 },
                Stroke = Brushes.LightBlue,
                StrokeThickness = 2
            };

            // 2. Định vị trí xuất hiện ngẫu nhiên ở đáy màn hình
            double startX = random.Next(0, (int)MainCanvas.ActualWidth - (int)bubble.Width);
            double startY = MainCanvas.ActualHeight;

            Canvas.SetLeft(bubble, startX);
            Canvas.SetTop(bubble, startY);

            MainCanvas.Children.Add(bubble);

            // 3. Thiết lập hiệu ứng dịch chuyển dọc (TranslateY)
            DoubleAnimation moveY = new DoubleAnimation
            {
                From = startY,
                To = -100, // Bay lên khỏi màn hình
                Duration = TimeSpan.FromSeconds(random.Next(4, 8)),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
            };

            // 4. Thiết lập hiệu ứng mờ dần khi bay lên
            DoubleAnimation fade = new DoubleAnimation
            {
                From = 1.0,
                To = 0.0,
                Duration = moveY.Duration
            };

            // 5. Tạo hiệu ứng lắc lư ngang (TranslateX) nhẹ để bọt khí bay tự nhiên
            DoubleAnimation moveX = new DoubleAnimation
            {
                From = startX,
                To = startX + random.Next(-30, 30),
                Duration = TimeSpan.FromSeconds(moveY.Duration.TimeSpan.TotalSeconds / 2),
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };

            // 6. Nhóm các hiệu ứng vào Storyboard
            Storyboard storyboard = new Storyboard();
            storyboard.Children.Add(moveY);
            storyboard.Children.Add(fade);
            storyboard.Children.Add(moveX);

            // Gán đối tượng mục tiêu cho các Animation
            Storyboard.SetTarget(moveY, bubble);
            Storyboard.SetTargetProperty(moveY, new PropertyPath("(Canvas.Top)"));

            Storyboard.SetTarget(fade, bubble);
            Storyboard.SetTargetProperty(fade, new PropertyPath(UIElement.OpacityProperty));

            Storyboard.SetTarget(moveX, bubble);
            Storyboard.SetTargetProperty(moveX, new PropertyPath("(Canvas.Left)"));

            // Dọn dẹp bộ nhớ (xóa UI element) khi Animation kết thúc
            storyboard.Completed += (s, ev) =>
            {
                MainCanvas.Children.Remove(bubble);
            };

            // 7. Bắt đầu chạy hiệu ứng
            storyboard.Begin();
        }
    }
}